let express = require('express');
let router = express.Router();
let upload = require('../../config/multer.config.js');

console.log("file router");
console.log(__basedir + '/uploads/')

var fileWorker = require('../controller/fileController.js');
router.post('/api/file/upload', upload.single("file"), fileWorker.uploadFile);
 module.exports = router;