'use strict';

module.exports = function (app) {
  
  var image = require('../controller/imageController');
  // image Routes
  app.route('/image/create')
    .post(image.create)
  app.route('/image')
    .get(image.listAll) 
  app.route('/image/delete/:imageid')
    .delete(image.delete)  
};