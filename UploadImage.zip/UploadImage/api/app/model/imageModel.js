'user strict';
var sql = require('../db.js');

//Image object constructor
var Image = function (image) {
    this.image = image.image;
    this.create_date = new Date();
};

// get data
Image.getAll = function getAllImage(result) {
    sql.query("Select a.blogid,a.image,a.create_date FROM image AS a order by create_date desc",function (err, res) {
      if (err) {
        console.log("error: ", err);
        result(null, err);
      }
      else {
        console.log('get images : ', res);
        result(null, res);
      }
    });
};

// create new image
Image.create = function createImage(newImage, result) {
    sql.query("INSERT INTO image set ?", newImage, function (err, res) {
        if (err) {
            console.log("error: ", err);
            result(err, null);
        }
        else {
            console.log("success: ", res);
            result(null, res.insertId);
        }
    });
};

//delete image by id
Image.remove = function (imageid, result) {
    console.log(imageid);
    sql.query("DELETE FROM image WHERE blogid = ?", [imageid], function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(null, err);
        }
        else {
            console.log("res: ", res);
            result(null, res);
        }
    });
};

module.exports = Image;