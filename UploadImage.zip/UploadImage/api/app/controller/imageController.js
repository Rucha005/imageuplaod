'use strict';
const fs = require('fs');
var Image = require('../model/imageModel.js');

//list all categories
exports.listAll = function (req, res) {
    Image.getAll(function (err, image) {
        if (err)
            res.send(err);
        res.send(image);
    });
};

// create image data
exports.create = function (req, res) {
    var newimage = new Image(req.body);
    //handles null error 
    if (!newimage.image) {
        res.status(400).send({ error: true, message: 'Please provide image' });
    }
    else {
        Image.create(newimage, function (err, image) {
            if (err)
                res.send(err);
            res.json(image);
        });
    }
};

// delete image
exports.delete = function (req, res) {
    Image.remove(req.params.imageid, function (err, image) {
        if (err)
            res.send(err);
        res.json({ message: 'Image successfully deleted' });
    });
};
