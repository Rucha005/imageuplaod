for i in aboutus allproducts cart-table check-out contactus customer display-levels faq footer forgot-password forgot-username header home home-slider login myaccount my-product-review mywishlist order-cancellation order-summery product-cart products rating  single-product terms view-cart view-wishlist wishlist 
do
ng g m $i --routing
ng g c $i/$i
ng g s $i/$i/$i
cp /home/backup-user/angular_RD/RUCHA_web_frontend/src/app/$i/* /home/backup-user/angular_RD/voyagekart-web-frontend-modules/src/app/$i/$i
done



