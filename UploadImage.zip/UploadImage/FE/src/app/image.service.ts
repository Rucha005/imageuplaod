import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { AllServices } from './allservice.service';
import 'rxjs/add/operator/map'


@Injectable()
export class ImageService {

  constructor(private http: Http) { }

  //get all blogs data
  getAllData() {
    return this.http.get(AllServices.getAllData)
      .map((response: Response) => response.json());
  }

  //create new blog 
  addNewImage(data) {
    return this.http.post(AllServices.addNewImage, data)
      .map((response: Response) => response.json());
  }

  //delete blog
  deleteImage(id) {
    return this.http.delete(AllServices.removeImage + '/' + id)
      .map((response: Response) => response.json());
  }

}