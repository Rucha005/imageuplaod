import { NgModule } from "@angular/core";
import { AppComponent } from "./app.component";
import { AppRoutingModule } from "./app-routing.module";
import { CommonModule } from "@angular/common";

import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { BlogComponent } from './blog/blog.component';

/** services file */
import { ImageService } from './image.service';
import { UploadFileService } from './upload-file.service';


@NgModule({
  declarations: [
    AppComponent,
    BlogComponent,
  ],
  imports:[
    CommonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserModule,
    CommonModule, 
    AppRoutingModule, 
    HttpModule
  ],
  providers:[ImageService,UploadFileService],
})

export class AppModule { }
