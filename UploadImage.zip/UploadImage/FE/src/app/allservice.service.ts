import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';

@Injectable()
export class AllServices 
{
    constructor(){}

    static ip = environment.ip;

    /** blog services */
    static getAllData = AllServices.ip + "/image";
    static addNewImage     = AllServices.ip + "/image/create";
    static removeImage     = AllServices.ip + "/image/delete";
  
} 