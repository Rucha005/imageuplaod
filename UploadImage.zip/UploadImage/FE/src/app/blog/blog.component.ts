import { Component, OnInit} from '@angular/core';
import { ImageService } from '../image.service';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { HttpResponse, HttpEventType } from '@angular/common/http';
import { UploadFileService } from '../upload-file.service';
import { environment } from '../../environments/environment';


@Component({
  selector: 'app-blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {

  errorStatus: any;
  getDataValues: any;
  displayTableFlag: boolean;
  displayAddFlag: boolean = false;
  Form: FormGroup;
  blogSuccessMessage: any;
  blogid: any;
  blogindex: number;
  imageUploadForm: FormGroup;
  filename: any;
  selectedFiles: FileList;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };
  imageurl: any;
  blogErrorMessage: string;
  imgURL : Image [] = [] ;
  fileUpload: string;


  constructor(private imageService: ImageService, private fb: FormBuilder, private uploadService: UploadFileService) {
    this.Form = this.fb.group(
      {
        'blogid': [null, Validators.required],
        'image': ['', Validators.required],
        'create_date': ['', Validators.required],
      }
    );
    this.imageUploadForm = this.fb.group(
      {
        'file': ['', Validators.required]
      }
    );
  }
  
  ngOnInit() {
    this.imageurl = environment.ip + '/';
    this.getData();
  }


  getData() {
    this.displayTableFlag = true;  
    this.imageService.getAllData()
      .subscribe(items => {
        this.getDataValues = items;
        this.getDataValues.image = this.imageurl + this.getDataValues.image;
    }, (error) => {
        this.errorStatus = JSON.parse(error._body);
      });
  }

  addNew() {
    this.Form.reset();
    this.displayTableFlag = false;
    this.displayAddFlag = true;
  }

  selectFile(event,files) {
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.blogErrorMessage = "Only images are supported.";
      return;
    }else{
      var filesAmount = event.target.files.length;
        for (let i = 0; i < filesAmount; i++) {
          var reader = new FileReader();
          reader.onload = (event:any) => {
            this.imgURL.push ({
              'imageurl': event.target.result,
              'imagevalue': event.target.value
            })
          }
          this.filename =  event.target.value.slice(12);
          this.selectedFiles = event.target.files;
          reader.readAsDataURL(event.target.files[i]);
        }

    
   
    this.progress.percentage = 0;
    this.currentFileUpload = this.selectedFiles.item(0);
    this.uploadService.pushFileToStorage(this.currentFileUpload).subscribe(event => {
      if (event.type === HttpEventType.UploadProgress) {
        this.progress.percentage = Math.round(100 * event.loaded / event.total);
      } else if (event instanceof HttpResponse) {
        this.fileUpload  = 'File is completely uploaded!'
      }
    });
    
    this.selectedFiles = undefined;
   }
  }

  removeImage(index){
    console.log("delete file:..", index)
    this.imgURL.splice(index, 1)
  }

  submitData() {
    this.Form.controls['image'].setValue(this.filename);
    console.log(JSON.stringify(this.Form.value));   
    this.imageService.addNewImage(this.Form.value)
      .subscribe(items => {
        //console.log(items);
        this.blogid = items.id;
        this.blogSuccessMessage = items.message;
        this.removeMessage();
        setTimeout(() => {
          this.displayTableFlag = true;
          this.displayAddFlag = false;
          this.getData();
        }, 3000);
      }, (error) => {
        this.blogErrorMessage = "Error in saved record";
        this.removeMessage();
      });
  }

  cancelButton() {
    this.displayTableFlag = true;
    this.displayAddFlag = false;
  }

  deleteData(id) {
    this.imageService.deleteImage(id)
      .subscribe(items => {
        console.log(items);
        this.getData();
      }, (error) => {});
  }
  
  removeMessage() {
    setTimeout(() => {
      this.blogSuccessMessage = null;
      this.blogErrorMessage = null;
    }, 3000);
  }
}

export interface Image{
  'imageurl': any,
  'imagevalue':any,
}