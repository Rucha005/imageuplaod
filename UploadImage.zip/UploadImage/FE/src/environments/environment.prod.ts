export const environment = 
{
  production: true,
  ip: 'http://localhost:3000',
  errorTimeoutms : 3000
};
